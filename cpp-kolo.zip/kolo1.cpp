// Grzegorz, Fica, ZSZiAD, 101306


#include <iostream>
using namespace std;

int main(int argc, char **argv) {
  cout<<"I love git!"<<endl;
  return 0;
}

